================================================================================
License Agreement
================================================================================

The license agreement for this software (hereinafter referred to as the
SOFTWARE) is described as follows.

1. Intellectual property rights in the SOFTWARE shall remain in
   FUJIFILM Business Innovation Corp. (hereinafter referred to as 
   FUJIFILM Business Innovation) as well as the original copyright holders.

2. The SOFTWARE can only be used with compatible FUJIFILM Business Innovation
   products (hereinafter referred to as the COMPATIBLE PRODUCTS) within the
   country of purchase of the COMPATIBLE PRODUCTS.

3. You are required to abide by the notes and restrictions (hereinafter referred
   to as the NOTES AND RESTRICTIONS) declared by FUJIFILM Business Innovation
   while using the SOFTWARE.

4. You are not permitted to alter, modify, reverse engineer, decompile or
   disassemble the whole or any part of the SOFTWARE for the purpose of
   analyzing the SOFTWARE.

5. You are not permitted to distribute the SOFTWARE on a communication network,
   or transfer, sell, rent or license the SOFTWARE to any third party by
   duplicating the SOFTWARE on any media such as floppy disk or magnetic tape.

6. FUJIFILM Business Innovation, FUJIFILM Business Innovation Channel Partners,
   Authorized Dealers and the original copyright holders of the SOFTWARE shall
   not be liable for any loss or damage arising from matching of hardware or 
   program that are not specified in the NOTES AND RESTRICTIONS of the SOFTWARE,
   or any modification to the SOFTWARE.

7. FUJIFILM Business Innovation, FUJIFILM Business Innovation Channel Partners,
   Authorized Dealers and the original copyright holders of the SOFTWARE shall
   not be responsible for any warranty or liability with respect to the SOFTWARE.

================================================================================
PCL 6 Print Driver Ver.2.6.31 Additional Information
================================================================================

This document provides information about the driver on the
following items:

1. Target Hardware Products
2. Requirements
3. General Comments
4. NOTES AND RESTRICTIONS
5. Software Update

---------------------------------------------------
1. Target Hardware Products
---------------------------------------------------
DocuPrint CM305 df

---------------------------------------------------
2. Requirements
---------------------------------------------------
Please note that this driver operates on a computer running on the following
operating system.

  Microsoft(R) Windows Server(R) 2012
  Microsoft(R) Windows Server(R) 2012 R2
  Microsoft(R) Windows(R) 10 x64 Editions
  Microsoft(R) Windows Server(R) 2016
  Microsoft(R) Windows Server(R) 2019
  Microsoft(R) Windows(R) 11
  Microsoft(R) Windows Server(R) 2022

  Please visit our web site to check the latest software and supported
  operating systems.

* Correspond to the company name change.
  The driver settings cannot be taken over because you cannot upgrade the driver
  from a driver with the old company name. Please clean install the new version.

---------------------------------------------------
3. General Comments
---------------------------------------------------
* Close all the running applications before installing the print driver.

* Always reboot the computer after installing an upgraded version of the print
  driver.

* If you have deleted an older version of the print driver, always reboot the
  computer before installing the new version.

* Some applications provide printing options pertaining to the number of copies
  and collated copies. Always select the printing options in the application
  unless the instructions specify otherwise. Use the print driver dialogs to
  select advanced options such as 2-Sided Print, Sample Set or options that
  are not available in the application.

* Always close the print driver dialogs and/or the application Print dialog box
  before you make any changes to the default settings of the print driver via
  the Control Panel.

* For the installation through the networks, if you right-click
  on [Printer] folder, go to [Run as administrator] from the menu and select
  [Add printer...], printer icon may not be generated.

* Rename a Printer Icon should comply OS file naming convention. Use Symbols or
  special characters may incur renaming error or unexpected print driver
  behavior.

---------------------------------------------------
4. NOTES AND RESTRICTIONS
---------------------------------------------------
* When monitoring print jobs with this driver, please use Fujifilm Document Monitor
  ver. 2 or later.

* Functional Limitations of EMF Spooling
   When [EMF Spooling] of [Detailed Settings] tab is set to [Available],
   the following features may not function normally.
   To use these features, set [EMF Spooling] to [Not Available].
   *[Secure Print][Sample Print]
   *[Enable Account Setup] [Detailed User Settings]
   *[Create/Register Forms]
   *[Separators] of [Separators/Covers]
   *[ICM Adjustment] of [Image Adjustment Mode]
   *[Use Extended Features From Application]
   *[Enable user defined margins]
   *All features of Direct Fax Driver
   For the details of [Annotation] limitations, refer to "Annotation
   features".

   When [EMF Spooling] of [Detailed Settings] tab is set to
   [Not Available], some documents with complex structure may have
   troubles such as distorted
   output image and failure of the output.

* Annotation and Watermark may not be printed even if [Annotation] and
  [Watermark] are specified.
  To make them function, set [EMF Spooling] to [Enabled] on the [Advanced] tab.

* To print in color from Application of Windows Store, open  
  [Devices and Printers] from Windows Desktop, right-click on 
  your printer to select [Print Settings] and then confirm that 
  [Output Color] on the [Paper / Output] tab of the [Print Setting] 
  dialog is set to [Color].
  If the setting of [Output Color] on the [Paper / Output] tab of 
  the [Print Settings] dialog remains [Black and White], the output 
  will be in black and white even if you specify [Output Color] 
  to [Color] on the printing setting screen shown after 
  you select printer from the device charm.

* If you set EMF Spooling to [Enabled] and perform 2-Sided Print 
  with documents of odd number of pages, a blank page may be inserted 
  on the last page depending on application or OS.

* Blank Separators
  If you set [EMF Spooling] to [Enabled] or specify Header, Footer and Watermark,
  and perform [2-Sided Print] with documents of odd number of pages, a blank page
  may be inserted on the last page depending on application or OS.

---------------------------------------------------
5. Software Update
---------------------------------------------------
    The latest software is available on our web site.

        https://fujifilm.com/fbglobal

    Communication charges will be borne by the customer.

--------------------------------------------------------------------------------
Microsoft, Windows and Windows Server are either registered trademarks or
trademarks of Microsoft Corporation in the United States and/or other countries.

Other company names and product names are trademarks or registered
trademarks of the respective companies.

libjpeg 6b
----------
This software is based in part on the work of the Independent JPEG Group.

(C) FUJIFILM Business Innovation Corp. 2011-2023
